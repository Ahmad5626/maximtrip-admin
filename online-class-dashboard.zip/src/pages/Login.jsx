import { useEffect, useRef, useState } from "react"
import { Link, useLocation, useNavigate } from "react-router-dom"
import { toast, Toaster } from "sonner"
import { useAuth } from "../contexts/authContext"
import axios from "axios"

function Login() {
    
    const [showPassword, setShowPassword] = useState(false)
    const [emailValue, setEmailValue] = useState('')
    const [passwordValue, setPasswordValue] = useState('')
   
const VALUE_EMIAL=import.meta.env.VALUE_EMAIL
const VALUE_PASSWORD=import.meta.env.VALUE_PASSWORD



    useEffect(() => {
        document.title = "Login | Grade Topper"
      

       
    })

    const navigate = useNavigate()

    async function handleSubmit(e) {
        e.preventDefault()
      
     
     
     
        if(emailValue=="anuj@gmail.com" && passwordValue=="Anuj@123###"){
            navigate('/overview/home')
        }
        else{
            toast.error('Please enter valid credentials', { duration: 3000 })
        }
       
        
        
    }

    return (
        <>
            <main className="h-[100dvh] flex items-center justify-center bg-[url('/img/login-cover.svg')] bg-cover bg-center px-4 sm:px-6 lg:px-8">
                <Toaster position="top-center" />
                <div className="w-[320px] min-h-96 px-8 py-6 text-left bg-gray-800 border border-gray-700 bg-opacity-70 backdrop-blur-lg rounded-xl shadow-lg">
                    <form onSubmit={handleSubmit}>
                        <div className="flex flex-col h-full select-none">
                            <div className="mb-5 flex justify-center">
                                <img src="/img/vyapar-logo.png" className="w-20" />
                            </div>
                            <div className="w-full flex flex-col gap-2">
                                <label className="font-semibold text-xs text-white tracking-wide">Email</label>
                                <input className="border rounded-lg px-3 py-2 mb-5 text-white text-sm w-full outline-none border-gray-600 bg-gray-600 bg-opacity-40 placeholder:text-gray-400" placeholder="example@mail.com" type="email" name="email" value={emailValue} onChange={(e) => setEmailValue(e.target.value)} />
                            </div>
                        </div>
                        <div className="w-full flex flex-col gap-2">
                            <label className="font-semibold text-xs text-white tracking-wide">Password</label>
                            <div className="flex justify-between items-center border-gray-600 bg-gray-600 bg-opacity-40 border rounded-lg px-3 py-2 mb-3">
                                <input type={showPassword ? "text" : "password"} value={passwordValue} onChange={(e) => setPasswordValue(e.target.value)} className="bg-transparent text-white text-sm w-full outline-none placeholder:text-gray-400" placeholder="••••••••" name="password" />
                                <button type="button" className="text-gray-400 text-sm" onClick={() => setShowPassword(!showPassword)}>
                                    {showPassword ? <i className="fa-regular fa-eye-slash text-white"></i> : <i className="fa-regular fa-eye text-white"></i>}
                                </button>
                            </div>
                        </div>
                      
                        <div>
                            <button type="submit" className="py-2 text-sm bg-blueClr focus:ring-offset-blue-200 text-white w-full transition ease-in duration-200 flex justify-center text-center font-semibold shadow-md focus:outline-none rounded-lg cursor-pointer select-none">
                            LOGIN
                            </button>
                        </div>
                    </form>
                   
                </div>
            </main>
        </>
    )
}

export default Login
